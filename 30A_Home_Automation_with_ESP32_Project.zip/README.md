# 30A Home Automation with ESP32

This repository contains the KiCad design files, Gerber manufacturing files and documentation screenshots for the **30A Home Automation with ESP32** project.

## Original Notes

```
*30A Home Automation With ESP32*
![](docs/top_image.png)
![](docs/bottom_image.png)
##schematic 
![](docs/30A_Home_Automation_with_ESP32.pdf)
```
